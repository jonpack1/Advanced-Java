/**
 * AUTHOR: Jon Pack
 * OCCC - ADVANCED JAVA
 * DATE: 04 04, 2024
 * PROJECT NAME: JCP_PingPong.java
 * DESCRIPTION: Pong
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Random;

    public class JCP_PingPong extends JPanel implements ActionListener, KeyListener {
        // Paddle properties
        private int paddleWidth = 10;
        private int paddleHeight = 60;
        private int paddleSpeed = 35;
        private int paddle1Y = 200;
        private int paddle2Y = 200;

        // Ball properties
        private int ballSize = 10;
        private int ballX = 300;
        private int ballY = 200;
        private int ballSpeedX = 3;
        private int ballSpeedY = 2;

        private Timer timer;

        public JCP_PingPong() {
            setPreferredSize(new Dimension(520, 520));
            setBackground(Color.BLACK);

            timer = new Timer(10, this);
            timer.start();

            // Randomize initial ball direction
            Random rand = new Random();
            ballSpeedX = rand.nextBoolean() ? 3 : -3; // Randomly set initial x-direction
            ballSpeedY = rand.nextBoolean() ? 2 : -2; // Randomly set initial y-direction

            // Add KeyListener to the panel
            addKeyListener(this);
            setFocusable(true); // Ensure the panel is focusable
            requestFocusInWindow(); // Request focus when the panel is displayed
        }

        @Override
        public void paintComponent(Graphics g) {
            super.paintComponent(g);

            // Draw paddles
            g.setColor(Color.WHITE);
            g.fillRect(20, paddle1Y, paddleWidth, paddleHeight);
            g.fillRect(getWidth() - 30, paddle2Y, paddleWidth, paddleHeight);

            // Draw ball
            g.fillOval(ballX - ballSize / 2, ballY - ballSize / 2, ballSize, ballSize);
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            // Move ball
            ballX += ballSpeedX;
            ballY += ballSpeedY;

            // Collision with walls
            if (ballY <= 0 || ballY >= getHeight()) {
                ballSpeedY = -ballSpeedY;
            }

            // Collision with paddles
            if (ballX <= 20 + paddleWidth && ballY > paddle1Y && ballY < paddle1Y + paddleHeight) {
                ballSpeedX = -ballSpeedX;
            }
            if (ballX >= getWidth() - 30 - paddleWidth && ballY > paddle2Y && ballY < paddle2Y + paddleHeight) {
                ballSpeedX = -ballSpeedX;
            }

            // Check if ball missed the paddle
            if (ballX < 0 || ballX > getWidth()) {
                // Reset ball position
                ballX = getWidth() / 2;
                ballY = getHeight() / 2;
            }

            // Repaint the panel
            repaint();
        }

        // KeyListener methods
        @Override
        public void keyPressed(KeyEvent e) {
            switch (e.getKeyCode()) {
                case KeyEvent.VK_W:
                    movePaddle1Up();
                    break;
                case KeyEvent.VK_S:
                    movePaddle1Down();
                    break;
                case KeyEvent.VK_UP:
                    movePaddle2Up();
                    break;
                case KeyEvent.VK_DOWN:
                    movePaddle2Down();
                    break;
            }
        }

        @Override
        public void keyTyped(KeyEvent e) {}

        @Override
        public void keyReleased(KeyEvent e) {}

        public void movePaddle1Up() {
            paddle1Y -= paddleSpeed;
            if (paddle1Y < 0) {
                paddle1Y = 0;
            }
            repaint();
        }

        public void movePaddle1Down() {
            paddle1Y += paddleSpeed;
            if (paddle1Y + paddleHeight > getHeight()) {
                paddle1Y = getHeight() - paddleHeight;
            }
            repaint();
        }

        public void movePaddle2Up() {
            paddle2Y -= paddleSpeed;
            if (paddle2Y < 0) {
                paddle2Y = 0;
            }
            repaint();
        }

        public void movePaddle2Down() {
            paddle2Y += paddleSpeed;
            if (paddle2Y + paddleHeight > getHeight()) {
                paddle2Y = getHeight() - paddleHeight;
            }
            repaint();
        }
    }

