/**
 * AUTHOR: Jon Pack
 * OCCC - ADVANCED JAVA
 * DATE: 04 04, 2024
 * PROJECT NAME: JCP_Calculator.java
 * DESCRIPTION: calc
 */

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.*;
import java.awt.event.*;

    public class JCP_Calculator extends JPanel implements ActionListener {

        JTextField textField;
        JButton[] numberButton = new JButton[10];
        JButton[] functionButton = new JButton[9];
        JButton addButton, subButton, mulButton, divButton, negButton,
                clearButton, decimalButton, deleteButton, equalButton;
        JPanel panel;
        Font myFont = new Font("Int Free", Font.BOLD, 30);

        double num1 = 0;
        double num2 = 0;
        double result = 0;
        char operator;

        public JCP_Calculator() {
            setLayout(null);
            setPreferredSize(new Dimension(500, 500));
            textField = new JTextField();
            textField.setBounds(50, 25, 500, 50);
            textField.setFont(myFont);
            textField.setEditable(false);

            addButton = new JButton("+");
            subButton = new JButton("-");
            divButton = new JButton("/");
            mulButton = new JButton("*");
            clearButton = new JButton("Clear");
            deleteButton = new JButton("Delete");
            equalButton = new JButton("=");
            decimalButton = new JButton(".");
            negButton = new JButton("(-)");

            functionButton[0] = addButton;
            functionButton[1] = subButton;
            functionButton[2] = divButton;
            functionButton[3] = mulButton;
            functionButton[4] = clearButton;
            functionButton[5] = deleteButton;
            functionButton[6] = equalButton;
            functionButton[7] = decimalButton;
            functionButton[8] = negButton;

            for (int i = 0; i < 9; i++) {
                functionButton[i].addActionListener(this);
                functionButton[i].setFont(myFont);
                functionButton[i].setFocusable(false);
            }
            for (int i = 0; i < 10; i++) {
                numberButton[i] = new JButton(String.valueOf(i));
                numberButton[i].addActionListener(this);
                numberButton[i].setFont(myFont);
                numberButton[i].setFocusable(false);
            }


            negButton.setBounds(70, 453, 145, 50);
            deleteButton.setBounds(235, 453, 145, 50);
            clearButton.setBounds(395, 453, 145, 50);

            panel = new JPanel();
            panel.setBounds(50, 100, 500, 350);
            panel.setLayout(new GridLayout(4, 4, 10, 10));
            panel.setBackground(Color.gray);

            panel.add(numberButton[7]);
            panel.add(numberButton[8]);
            panel.add(numberButton[9]);
            panel.add(mulButton);
            panel.add(numberButton[4]);
            panel.add(numberButton[5]);
            panel.add(numberButton[6]);
            panel.add(subButton);
            panel.add(numberButton[1]);
            panel.add(numberButton[2]);
            panel.add(numberButton[3]);
            panel.add(addButton);
            panel.add(numberButton[0]);
            panel.add(decimalButton);
            panel.add(equalButton);
            panel.add(divButton);

            add(deleteButton);
            add(clearButton);
            add(negButton);
            add(textField);
            add(panel);
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            // TODO Auto-generated method stub

            for(int i =0; i<10;i++) {
                if(e.getSource()== numberButton[i]) {
                    textField.setText(textField.getText().concat(String.valueOf(i)));
                }
            }
            if(e.getSource()== decimalButton) {
                textField.setText(textField.getText().concat("."));
            }
            if(e.getSource()== addButton) {
                num1 = Double.parseDouble(textField.getText());
                operator= '+';
                textField.setText("");
            }
            if(e.getSource()== subButton) {
                num1 = Double.parseDouble(textField.getText());
                operator= '-';
                textField.setText("");
            }
            if(e.getSource()== mulButton) {
                num1 = Double.parseDouble(textField.getText());
                operator= '*';
                textField.setText("");
            }
            if(e.getSource()== divButton) {
                num1 = Double.parseDouble(textField.getText());
                operator= '/';
                textField.setText("");
            }
            if(e.getSource()== equalButton) {
                num2 = Double.parseDouble(textField.getText());
                switch(operator) {
                    case'+':
                        result = num1+num2;
                        break;
                    case'-':
                        result = num1-num2;
                        break;
                    case'*':
                        result = num1*num2;
                        break;
                    case'/':
                        result = num1/num2;
                        break;
                }
                textField.setText(String.valueOf(result));
                num1= result;
            }
            if(e.getSource()== clearButton) {
                textField.setText("");
            }
            if(e.getSource()== deleteButton) {
                String string= textField.getText();
                textField.setText("");
                for(int i =0;i< string.length()-1;i++) {
                    textField.setText(textField.getText()+string.charAt(i));
                }

            }
            if(e.getSource()== negButton) {

                Double temp= Double.parseDouble(textField.getText());
                temp *= -1;
                textField.setText(String.valueOf(temp));

            }

        }
    }

