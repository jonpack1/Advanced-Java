/**
 * AUTHOR: Jon Pack
 * OCCC - ADVANCED JAVA
 * DATE: 04 04, 2024
 * PROJECT NAME: JCP_QuizGame.java
 * DESCRIPTION: quizgame
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

    public class JCP_QuizGame extends JPanel implements ActionListener {

        private String[] questions = {
                "What was the first assignment?",
                "What day is the eclipse this year 2024?",
                "Who is the Advanced Java Professor?",
                "How many widgets do we have for this assignment?"
        };
        private String[][] options = {
                {"Big Integer", "Sudoku", "Palindrome", "Shapes"},
                {"April 7", "April 8", "April 9", "April 10"},
                {"Chris", "Sara", "John", "Koffing"},
                {"1", "5", "4", "3"}
        };
        private char[] answers = {'A', 'B', 'C', 'C'};

        private int index = 0;
        private int correctGuesses = 0;
        private int totalQuestions = questions.length;
        private int seconds = 10;

        private JLabel questionLabel;
        private JButton[] optionButtons;
        private JLabel timeLabel;
        private JLabel secondsLeftLabel;

        private Timer timer;

        public JCP_QuizGame() {
            setLayout(new BorderLayout());
            setBackground(new Color(50, 50, 50));
            setPreferredSize(new Dimension(500, 500));

            questionLabel = new JLabel();
            questionLabel.setFont(new Font("Arial", Font.BOLD, 20));
            questionLabel.setForeground(Color.WHITE);
            add(questionLabel, BorderLayout.NORTH);

            JPanel optionsPanel = new JPanel(new GridLayout(4, 1, 5, 5));
            optionsPanel.setBackground(new Color(50, 50, 50));
            optionButtons = new JButton[4];
            for (int i = 0; i < optionButtons.length; i++) {
                optionButtons[i] = new JButton();
                optionButtons[i].setFont(new Font("Arial", Font.PLAIN, 16));
                optionButtons[i].setForeground(Color.BLACK);
                optionButtons[i].setBackground(Color.DARK_GRAY);
                optionButtons[i].addActionListener(this);
                optionsPanel.add(optionButtons[i]);
            }
            add(optionsPanel, BorderLayout.CENTER);

            JPanel timerPanel = new JPanel(new GridLayout(1, 2));
            timerPanel.setBackground(new Color(50, 50, 50));
            timeLabel = new JLabel("Timer:");
            timeLabel.setFont(new Font("Arial", Font.BOLD, 16));
            timeLabel.setForeground(Color.WHITE);
            timerPanel.add(timeLabel);
            secondsLeftLabel = new JLabel();
            secondsLeftLabel.setFont(new Font("Arial", Font.BOLD, 16));
            secondsLeftLabel.setForeground(Color.WHITE);
            timerPanel.add(secondsLeftLabel);
            add(timerPanel, BorderLayout.SOUTH);

            timer = new Timer(1000, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    seconds--;
                    secondsLeftLabel.setText(String.valueOf(seconds));
                    if (seconds <= 0) {
                        displayAnswer();
                    }
                }
            });

            nextQuestion();
        }

        public void nextQuestion() {
            if (index >= totalQuestions) {
                results();
            } else {
                questionLabel.setText("Question " + (index + 1) + ": " + questions[index]);
                for (int i = 0; i < optionButtons.length; i++) {
                    optionButtons[i].setText(options[index][i]);
                }
                timer.restart();
            }
        }

        public void actionPerformed(ActionEvent e) {
            timer.stop();
            for (int i = 0; i < optionButtons.length; i++) {
                optionButtons[i].setEnabled(false);
                if (e.getSource() == optionButtons[i]) {
                    char selectedAnswer = (char) ('A' + i);
                    if (selectedAnswer == answers[index]) {
                        correctGuesses++;
                    }
                    displayAnswer();
                    break;
                }
            }
        }

        public void displayAnswer() {
            timer.stop();
            for (int i = 0; i < optionButtons.length; i++) {
                optionButtons[i].setEnabled(false);
            }
            seconds = 10;
            secondsLeftLabel.setText(String.valueOf(seconds));
            index++;
            Timer pause = new Timer(2000, new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    for (int i = 0; i < optionButtons.length; i++) {
                        optionButtons[i].setEnabled(true);
                    }
                    nextQuestion();
                }
            });
            pause.setRepeats(false);
            pause.start();
        }

        public void results() {
            timer.stop();
            for (int i = 0; i < optionButtons.length; i++) {
                optionButtons[i].setEnabled(false);
            }
            int result = (int) ((correctGuesses / (double) totalQuestions) * 100);
            questionLabel.setText("Results:");
            secondsLeftLabel.setText("");
            for (int i = 0; i < optionButtons.length; i++) {
                optionButtons[i].setText("");
            }
            JOptionPane.showMessageDialog(this, "You scored " + result + "%");
        }
    }

